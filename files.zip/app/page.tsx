import { getSession } from "@/lib/get-session";
import Link from "next/link";
import Logo from "@/components/Logo";
import ThemeToggle from "@/components/ThemeToggle";

export default async function Home() {
  const session = await getSession();
  return (
    <div className="flex flex-col items-center mt-16">
      <Logo />
      <h1 className="text-3xl font-bold mt-4">Welcome to itsuki-gg.page.gd</h1>
      <p className="mt-2 text-lg">Discord verification dashboard for the community.</p>
      <div className="mt-6 flex gap-4">
        {!session ? (
          <Link
            href="/api/auth/signin"
            className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
          >
            Login with Discord
          </Link>
        ) : (
          <Link
            href="/dashboard"
            className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
          >
            Go to Dashboard
          </Link>
        )}
        <ThemeToggle />
      </div>
    </div>
  );
}
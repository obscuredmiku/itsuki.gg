import { getSession } from "@/lib/get-session";
import { prisma } from "@/lib/prisma";
import UserCard from "@/components/UserCard";
import WarningBanner from "@/components/WarningBanner";
import Link from "next/link";

export default async function Dashboard() {
  const session = await getSession();
  if (!session) {
    return (
      <div>
        <p>You must be logged in.</p>
        <Link href="/api/auth/signin">Login with Discord</Link>
      </div>
    );
  }

  const user = await prisma.user.findUnique({
    where: { discord_id: session.user.discord_id },
    include: { login_logs: true },
  });

  // Fetch warnings (alts, VPN)
  const altWarning = user && user.login_logs.length > 1; // Simplified
  const vpnWarning = user && user.login_logs.some((log) => log.vpn_flag);

  return (
    <div>
      <UserCard user={user} />
      {(altWarning || vpnWarning) && (
        <WarningBanner alt={altWarning} vpn={vpnWarning} />
      )}
      <form method="POST" action="/api/verify" className="mt-4">
        <button
          className="px-4 py-2 bg-blue-500 text-white rounded"
          disabled={user.verified || altWarning || vpnWarning}
        >
          {user.verified ? "Verified" : "Verify"}
        </button>
      </form>
    </div>
  );
}
import "./../styles/globals.css";
import Navbar from "@/components/Navbar";
import AuthProvider from "@/components/AuthProvider";

export const metadata = {
  title: "itsuki-gg.page.gd",
  description: "Discord Verification Dashboard",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        <AuthProvider>
          <Navbar />
          <main className="max-w-3xl mx-auto p-4">{children}</main>
        </AuthProvider>
      </body>
    </html>
  );
}
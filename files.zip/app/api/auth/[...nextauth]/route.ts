import NextAuth from "next-auth";
import DiscordProvider from "next-auth/providers/discord";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { prisma } from "@/lib/prisma";
import type { NextAuthOptions } from "next-auth";
import { supabase } from "@/lib/supabase";

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  providers: [
    DiscordProvider({
      clientId: process.env.DISCORD_CLIENT_ID!,
      clientSecret: process.env.DISCORD_CLIENT_SECRET!,
      authorization: { params: { scope: "identify email" } },
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      // Save to Supabase as well, ensure Discord ID unique
      const { data, error } = await supabase
        .from("users")
        .upsert(
          {
            discord_id: profile.id,
            username: profile.username,
            email: profile.email,
            avatar: profile.avatar,
          },
          { onConflict: "discord_id" }
        );
      return !error;
    },
    async session({ session, user }) {
      session.user.id = user.id;
      session.user.discord_id = user.discord_id;
      session.user.avatar = user.avatar;
      session.user.verified = user.verified;
      return session;
    },
  },
  session: { strategy: "jwt" },
  secret: process.env.NEXTAUTH_SECRET,
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
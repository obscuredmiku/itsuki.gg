import { getSession } from "@/lib/get-session";
import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { fingerprint } = await req.json();
  const ip = req.headers.get("x-forwarded-for") || req.ip || "unknown";

  // Check for alts
  const logs = await prisma.loginLog.findMany({
    where: { OR: [{ ip }, { fingerprint }] },
  });
  const isAlt = logs.some((log) => log.user_id !== session.user.id);

  // Save log
  await prisma.loginLog.create({
    data: {
      user_id: session.user.id,
      ip,
      fingerprint,
      vpn_flag: false, // Updated later if flagged
    },
  });

  return NextResponse.json({ isAlt });
}
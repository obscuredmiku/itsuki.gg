import { getSession } from "@/lib/get-session";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function POST() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  // Check if flagged as alt or VPN
  const user = await prisma.user.findUnique({
    where: { discord_id: session.user.discord_id },
    include: { login_logs: true },
  });
  const isAlt = user.login_logs.length > 1;
  const isVPN = user.login_logs.some((log) => log.vpn_flag);

  if (isAlt || isVPN) {
    return NextResponse.json({ error: "Cannot verify flagged account." }, { status: 403 });
  }

  await prisma.user.update({
    where: { discord_id: session.user.discord_id },
    data: { verified: true },
  });

  return NextResponse.redirect("/dashboard");
}
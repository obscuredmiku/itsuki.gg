import { getSession } from "@/lib/get-session";
import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

const API_KEY = process.env.IPQS_KEY!; // e.g., IPQualityScore

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { ip } = await req.json();

  // Call external VPN/proxy API
  const res = await fetch(`https://ipqualityscore.com/api/json/ip/${API_KEY}/${ip}`);
  const data = await res.json();
  const isVPN = data.vpn || data.proxy || data.tor;

  // Update login log
  await prisma.loginLog.updateMany({
    where: { user_id: session.user.id, ip },
    data: { vpn_flag: isVPN },
  });

  return NextResponse.json({ isVPN });
}
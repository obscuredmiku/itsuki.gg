import { getSession } from "@/lib/get-session";
import { isAdmin } from "@/lib/admin-check";
import { prisma } from "@/lib/prisma";

export default async function AdminPanel() {
  const session = await getSession();
  if (!session || !isAdmin(session.user.discord_id)) {
    return <p>Access denied.</p>;
  }

  const flaggedUsers = await prisma.user.findMany({
    where: {
      OR: [
        { login_logs: { some: { vpn_flag: true } } },
        { login_logs: { some: { user_id: { not: undefined } } } }, // Simplified alt check
      ],
    },
    include: { login_logs: true },
  });

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Panel</h1>
      <h2 className="text-lg mb-2">Flagged Users</h2>
      <table className="w-full text-sm">
        <thead>
          <tr>
            <th>Username</th>
            <th>Discord ID</th>
            <th>VPN?</th>
            <th>Alts?</th>
            <th>Verified</th>
          </tr>
        </thead>
        <tbody>
          {flaggedUsers.map((u) => (
            <tr key={u.id}>
              <td>{u.username}</td>
              <td>{u.discord_id}</td>
              <td>{u.login_logs.some((l) => l.vpn_flag) ? "Yes" : "No"}</td>
              <td>{u.login_logs.length > 1 ? "Yes" : "No"}</td>
              <td>{u.verified ? "Yes" : "No"}</td>
              {/* Add manual verify/unverify controls if desired */}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
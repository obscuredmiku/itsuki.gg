import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";

const protectedRoutes = ["/dashboard", "/admin"];

export async function middleware(req: NextRequest) {
  if (protectedRoutes.some((r) => req.nextUrl.pathname.startsWith(r))) {
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token) {
      return NextResponse.redirect(new URL("/api/auth/signin", req.url));
    }
    if (
      req.nextUrl.pathname.startsWith("/admin") &&
      !process.env.ADMIN_DISCORD_IDS?.split(",").includes(token.discord_id)
    ) {
      return NextResponse.json({ error: "Not authorized" }, { status: 403 });
    }
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard", "/admin"],
};
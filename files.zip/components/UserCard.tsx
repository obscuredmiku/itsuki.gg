export default function UserCard({ user }: { user: any }) {
  if (!user) return null;
  return (
    <div className="p-6 rounded bg-white dark:bg-gray-800 shadow flex items-center gap-4">
      <img
        src={`https://cdn.discordapp.com/avatars/${user.discord_id}/${user.avatar}.png`}
        alt="avatar"
        className="w-16 h-16 rounded-full"
      />
      <div>
        <div className="font-bold text-xl">{user.username}</div>
        <div className="text-gray-500">{user.email}</div>
        <div>
          Status:{" "}
          <span className={user.verified ? "text-green-600" : "text-yellow-600"}>
            {user.verified ? "Verified" : "Unverified"}
          </span>
        </div>
      </div>
    </div>
  );
}
export default function WarningBanner({
  alt,
  vpn,
}: {
  alt?: boolean;
  vpn?: boolean;
}) {
  if (!alt && !vpn) return null;
  return (
    <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 my-4 rounded">
      <strong>Warning:</strong>
      <ul className="list-disc ml-6">
        {alt && <li>Possible alt account activity detected.</li>}
        {vpn && <li>VPN/Proxy detected - verification blocked.</li>}
      </ul>
    </div>
  );
}
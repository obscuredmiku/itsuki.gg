export default function Logo({ size = 48 }: { size?: number }) {
  return (
    <img
      src="/itsuki-gg-logo.png"
      alt="Logo"
      width={size}
      height={size}
      className="rounded"
    />
  );
}
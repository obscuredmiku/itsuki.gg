import Link from "next/link";
import ThemeToggle from "./ThemeToggle";
import Logo from "./Logo";
import { getSession } from "@/lib/get-session";

export default async function Navbar() {
  const session = await getSession();
  return (
    <nav className="flex justify-between items-center py-4 mb-8 border-b">
      <div className="flex items-center gap-3">
        <Logo size={32} />
        <span className="font-bold text-lg">itsuki-gg</span>
      </div>
      <div className="flex gap-3 items-center">
        <Link href="/">Home</Link>
        {session && <Link href="/dashboard">Dashboard</Link>}
        {session?.user && (
          <Link href="/api/auth/signout" className="text-red-600">
            Sign out
          </Link>
        )}
        <ThemeToggle />
      </div>
    </nav>
  );
}
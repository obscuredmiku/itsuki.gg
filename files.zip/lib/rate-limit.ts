import type { NextRequest } from "next/server";

const RATE_LIMIT = 5; // 5 logins per hour per IP

const ipCache = new Map<string, { count: number; timestamp: number }>();

export function rateLimit(req: NextRequest): boolean {
  const ip = req.headers.get("x-forwarded-for") || req.ip || "unknown";
  const now = Date.now();
  const entry = ipCache.get(ip);

  if (!entry || now - entry.timestamp > 60 * 60 * 1000) {
    ipCache.set(ip, { count: 1, timestamp: now });
    return false;
  }
  if (entry.count >= RATE_LIMIT) {
    return true;
  }
  entry.count += 1;
  ipCache.set(ip, entry);
  return false;
}
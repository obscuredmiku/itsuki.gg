export function isAdmin(discordId: string) {
  if (!process.env.ADMIN_DISCORD_IDS) return false;
  return process.env.ADMIN_DISCORD_IDS.split(",").includes(discordId);
}
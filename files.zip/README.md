# itsuki-gg.page.gd

A secure Discord verification dashboard built with Next.js 14, TypeScript, Supabase, Prisma, NextAuth, and Tailwind CSS.

## Features

- Discord OAuth2 login (NextAuth.js)
- User dashboard: verification, warnings, Discord info
- Alt account and VPN/proxy detection (IP logging, fingerprinting, IPQualityScore)
- Admin panel (staff-only via ENV Discord IDs)
- Clean UI with Tailwind CSS, light/dark mode, logo
- Supabase PostgreSQL for data
- Prisma ORM
- Secure: protected routes, CSRF, secure cookies, rate limiting

## Setup

1. Copy `.env.example` to `.env` and fill out secrets.
2. Run `npm install`.
3. Run Prisma migrations: `npx prisma migrate dev`.
4. Start dev server: `npm run dev`.

Deployable to Vercel or any Node.js host.

---

**Security Note:**  
- Only staff Discord IDs listed in `ADMIN_DISCORD_IDS` can access `/admin`.
- All routes are protected and rate limited.